/***********************************************************************/
/*    Common Helper Functions
/***********************************************************************/
const isMobile = typeof navigator !== "undefined" && /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
const isFirefox = typeof browser !== "undefined" && typeof browser.runtime !== "undefined";
const IMAGE_PATH = "images/stremio-logo-small.png";

const getExtensionImageUrl = (path) => {
  try {
    if (typeof browser !== "undefined" && browser?.runtime?.getURL) {
      return browser.runtime.getURL(path);
    }
    if (typeof chrome !== "undefined" && chrome?.runtime?.getURL) {
      return chrome.runtime.getURL(path);
    }
  } catch (e) {
    // Fallback if accessed outside extension context
  }
  return path;
};

// Embedded Base64 Data URI guarantees the logo renders instantly and never breaks
const STREMIO_DATA_URI = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAYAAAA5ZDbSAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAkGVYSWZNTQAqAAAACAAGAQYAAwAAAAEAAgAAARIAAwAAAAEAAQAAARoABQAAAAEAAABWARsABQAAAAEAAABeASgAAwAAAAEAAgAAh2kABAAAAAEAAABmAAAAAAAAAEgAAAABAAAASAAAAAEAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAeKADAAQAAAABAAAAeAAAAACzuIXJAAAACXBIWXMAAAsTAAALEwEAmpwYAAADRmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNi4wLjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgICAgICAgICAgeG1sbnM6ZXhpZj0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC8iPgogICAgICAgICA8dGlmZjpDb21wcmVzc2lvbj4xPC90aWZmOkNvbXByZXNzaW9uPgogICAgICAgICA8dGlmZjpSZXNvbHV0aW9uVW5pdD4yPC90aWZmOlJlc29sdXRpb25Vbml0PgogICAgICAgICA8dGlmZjpYUmVzb2x1dGlvbj43MjwvdGlmZjpYUmVzb2x1dGlvbj4KICAgICAgICAgPHRpZmY6WVJlc29sdXRpb24+NzI8L3RpZmY6WVJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgICAgIDx0aWZmOlBob3RvbWV0cmljSW50ZXJwcmV0YXRpb24+MjwvdGlmZjpQaG90b21ldHJpY0ludGVycHJldGF0aW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MTk0PC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6Q29sb3JTcGFjZT4xPC9leGlmOkNvbG9yU3BhY2U+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj4xOTQ8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KcI9YsgAAHspJREFUeAHtXXu0XFV5/86cM/fm5iaByCM8AiEhJguxq1j0j1qqUJJAgNqqjZQAroVVWl+4UJuiVokKffiiq2IfuMpatjWB3KprIdZKggSftMKyWpFiMeGR8Egg5HGfM+fR32/v883sOTl37sy9M3NnLu5k7t7nO3t/+9v7d75vf2fvfc7x5CUREm/bBinsWPxQQeRcOeUXkty4UyJPvOQl0fy52sgkSbwNGxJ/svZt3pwU+Jvs/FygB3OhEXlt2LBhm+95XoRz0Yc2HDmh0O+vkTg5EyrrA9E9QVDYvnmz9yTL8iIYGjJ581j1NM3raeknEX4bAHsLANv0tmRhcXzkY+J5by0Uiif2BUUkRcphJGE0cVgS+UoYFDb/9T8PPLn5/PuCzTsvCCdh2bPkOQfw5vMTAOWFN2w8uML3grsG+gbPniiXJErCBI2NAKqIJwXP8wv9xX4ZL40+J0nhLTdvGfiOlu1ZNHMEn1MAK0A3bBwHuNGO/uL85ePl0TLaHXhCfKvNBc6EOiz684rlaHwMh7/7F19ecK/yyOmrniTNGQdDgSG4BS/e3hdYcAFp0SJbBZdIkcZzYTQOK903AI/6rg9fOXwhtR+O15zxTWpb3ZPXqIgLLjWX4JbCUY6nDQEFVY4Ash8l5dEkid8wlzS55zU4H9wxY5YbvV5xlfthXIp8rzgfw/Oc0uSe1mAXXJrl/mBgRakMzfUa09zsBWA1uehHMTRZEqvJMNe4nepZ77pnAXbBrZjlGYCrYM81c92TJtoFVx2qUgizPE3NVXAZ15rr3ne8ek6DXXBbqbkuyGk68ueA49VTGtxBcIlx1fHyetfx6hmAXXArZrkFY26O5lZIueYaDlcv3Sf3hIl2wW2zWa6Am0n0rLnueg2uBdfOULXKocqAWO+waq577D65qzX4aHBndp9bD8FGzlVuocx9cjrj1eX3yV0LcC246fRjm8fcpkDukWnNrjTRLrgVh6pF97mNgFgvT67j1cULFF2nwS64FYeqiYWDeuC08lzFXHe5JneVBueD29zCQStBrMerqsnBfK+L75O7BuBacFNvmWOuJMV6HT2b5yzI5XQVKp3W7LL75K4w0bXgNr+eO5sgs+5uNtezrsEK7kc2ji3zC/E96WJ9U+u5sw1w1Vyn68kbxy7gzpBrr31w1q3PrAJsdzJ6IcHFHvQdff7AmWY9F1tpZhu0ZuuvgFwAyF5y10evHnv9bbe9uswLuFlercw/ayba1VwDbjCwciaL9a3slJnwqpjruDxcKHiXffJfBu7n3PVsbRqYFQ12wU2ouQS3S+5zZwIuyzqavCCO47s/BE0muLO1QNFxDdYN5hWzPEc0N3thuJocQ5P/kpoMc82xOZu3nccd1WDbwAvMmFvVXOxbbsFOjHZ20nR4u5pciJO7OSbPxpbcjmmwXr1zXXOzF4OrybMxJncE4JeKWc6Cq8e5IHfIXLfdROeb5dZskNMO7PbYNdcVxwtjcSccr7Zq8Etdc7MXnqvJnXK82qbBruZW7nPnyK1QFrhGj11N7pTj1RYNdh2qxIv5rBDuc0fLqKyIq/glHBLcMOA5R0nwLFQ/twENJ4WCvYVq02RIywF2zXKskxjlETxO4jlTdi7MKsJs0Nw6ed01I0te2UZpzgIFQBYFuQ2Ol7aoJVrlam6Uau6E0dzOLfnxmVAPb+VI8PKGJNvfLWll65hAPPtUI6Y1PQW5xZrcMoBVcz+AhYMA4BZplo3m8uFrc8Ua/dA+nwlNu1h5mGMwLgDYCOtQI4cSGVjoSd+ASMy3dOAc63Xza1pj8tC0G5PuluU5hlbRwMpsyY0BcgyQP93iGS+V1wg93T8uuL4XAtwFAHc4Ncvau263KU1rTM+ZXms0n1MWqlrwPQPs8Sd7cuYrfXnqsVie+Fksx5wM4MAyxkuTzFuTcpFxz6X1mxcCqJxKQ51p0jB1YZ5U9koBFFZ+juxMJknk+/1+HE0MoymXfXrrwpZNa7L2GQU1y9RcLwW3HI5Aj2CWczsT1bltZu25+ZCJr7FyzzGvW5bnEKi5I4dEznmdL5e/fZ7MH/RkYjyRB79flqFbS+LPExlY4ElYSgu4PMjArYPnGFpJS6vNk93Q8AevfIoCv88Po9JwQUFugbnW5thGNfnX1Vwx4A6uLKdm2XRQk/ymlR0t8OG+vfB4Ih++bUBWrArM2EutZdj1i0i+fOu4PPVoLItP8YwJ59g8o4Zb1i3/C7GgyX3QZAfkGTpe074P1vtcam4i4Y4gGMSt0EgZli1gB/Kixe1AJp6Mls2PYyBQy2NyWoj1mUVLPKO57HVTP2XAb8UqX973ifny+jcF8twvIQ+sAjU+pmxaB2iVupqmOXJWyk6DRsE9PPAWTUSFQt+C0Evuvv6KIzNeoIBIzQc1y+/e+OKyPs+vjrnuOzHImb3mhjbQKixDTzZ9dkBOPtWv0eAkRr+ll/H3v12SrV+YwPvQRAaPwSt2Sq5wSCszjd3TraC5PDStMesyafPHaHIETfYS77JbZjAmN63B1ix74XuvHF3qi39PAIdqAg6V0VzISF0w2oA/Jm6KlpapKTsFDf3BeqiR7JpsILjUZIbf+p0+2fSZAVl6pif7n0zE58agtLyRlfXymDFO1fxmRMvpE1Ri+Lt8Dc3QORZHBb9vQezFd19/1eHfNkuNMNdsRzOhKYDVLBNcL4G3XBxcNR4OlyFjEKfCQWGs+avECY7zaWwKG2nMJVIaN0Vz6mW5vGDGY5xEVjl9eSDvu3FQ1l9VlOcAcgSiF1gZTb04phxWFguyHk9FY2s0L3nZn+XtlrX5tN2MmfeofH4Z5trz+xeEWE9+3xWHz5vOenLDAJ9vXvVnNVcAblAcXF0q4VYoSTD9yKbYBpmESVsahdeQzacdwPM2d7VTGqVZHmSgHFgyJ0AzCTRN9iA86suvGZDrbppnzPTwwUSCPtatEtryrnzKsR7NlcDyyvJTqnKz7bU119JsSc+MybiFWhQXkm8YkLn9pwlNbghgmuWdeI8jNTdOyjv8YHD1RHmkHMOhstppr8K8NBudR28VzeVf7aLJU67Jfs1r++Qjnx2UVef48uzuGJqMcuiRqmyqVdOhuWXqpevVYWC2muz1LYLj9Y13vTXV5AZBnhJgq7kWXLwojN7y6pIxy1Zz9ZrUK7t6bK9Be1zVjmo+pU2WTzlpPo3z8ttOmhzW2jN6C0VtPvV0X6770KD8wR/3yf49uB8IMTYDaK29Km+VMj2a8tR4Mn56XmPTXixMGO96kYRxUyDXBZjgUnPfDs0NFVw6VGZVyHaqbawKY6/Uo2lGyJpOy45JLFOlaf7GaSzfbKA2xwC5f54nb7piQDZ9akACvPjwxResA2bbYWWhVh/drmZo2qap+OXlM7QU5P5FSRMgTwrw+TABCm6gZhmaa81yFdyqOauC22maC0SzIBfQAxy++Tvn3D75808tkFe91pend+N+WU02z4Nxp9ulF5XWCxm4xBh6BYzJAPnaBhyvXICt5nrQ3BeW+kkJZnn+ajO3nK7nsrEMjN2f0jR287WThmk+0/msYzqBJps/avOSkwryng8OyjXX98u+vYlMTKQOGBrTsfagEW5dTPNnAU8CmmvP71vkeSnIdRwvNKs26NvPCW4hCQy4ZbNwML3XA9Zyb/2R8YzBNsZ2gk98boGckpnoaLZGarKO0T/7SVn+6e9HZe/jsZyARQy8drqbgn0xTFw67CX+pbdtXfQ9a3Vr913XaLCCe+2GA6dL4sNbhubq9COapldSd8aUaubBXDBgRaBf+etF+ejNC+S8NUXZswv3y+gts9bM86hqln9+FJVDTGsuirzoG2+74sB5O7GRL/uNigrA2OFX4HcLrr762RPDomCGCt5y+UgIx6dI54cTGXYsYJrmQmmkZ2l6XmPm0bTGaTmWrZxz0jU0zeuWTdOmo205JFsSCDJ/NNkvO86Xd1+/QN59wzw58HwiY2PWATNtNrKnspn+UTnzaCq7ym1lbqzvlJ/ysMeRlwRlzngBZAj89Wsu3/8bxJDfq9COSAFOPDw/w37GG7L7vtRXPHb1RDhcirHNhuNb9UrVtMb2SrfnHRpKNEZLtSCvjhpanXysC5WxPv1rki34ow6Yj+5at35AbsIQcMKSgjz7TGy8bVNjWrdtr8qZxqlE5lylPdo3yNMwTfk5ZQ1vHGOBIoomQvhJx3q+v+W9V76waGjoLREVlvKZPxvwTSEeXLPxxd8rBAMXj5cOYgYv6asIoI1g7KZRxgqfE2fz5ZU1tFRoN7+bZh2TlrX1qgVgG1odXJO9+qyifOymhXLJG2Gyn0Ct9GDwq+mTJmWvKQt2KF7LbzKa9gkYQJKAQ2lQPGb1cCLXoog8/PAQpbPAbttmrCTnZS9PMMiYSig4MrD7K3GraYY/dxlm68LxUXVNQtOyYEI+7QiuyT7m2IJc+86F8LQH5PBho0GprNpPk8jZUHtSfmgEuTXX71xqHAeG3lXsA2oxY6O5+L6Q6RtcC+dEcYkCe9Rejg88YccbVNpqGrjbOmxMTWSNhpbW1QjNlmFz2hvUZLOW9ZcOyLpLinLghRjry5R5erJr32o87T7GR8Ai7DQEdkuvuOLw8bYnEncrKwX0Ftqrhuk0Sxoz6kYaO5ZBZbNH7furzhfBXrmqKPxkTyv6TCXWdmhMuqY1npzGSz3x++IYq93y/ObNH88CLNiPKEtNtgpb2BaTdmOtIo/Gcww8x+CKpTSX3gyNvLRO8tCyVoNIaXeAYcE2ZlvLL3eFWFNm3XaYqe0n5lFZNc6jVdtQm59589qbpTGfDTxDwzcajx0mZfPmG3UBmSMerLIkP8eN3tm4JWLeNGQZ6ilX6Ho05cPYzaf0ZmlarsqPHJSLe7bVad42EdwythTeffeofPObE3LsYmzmM6MdJXD7hLU3QnMl17TGyoMxQx4/0k29MNJ4L6DI00NDJ+8nlZiaa1G9aOS7gyzsj3ps03acVHqztNpy5DkzflW5VD6XJ9i3POjlTnD37YvkM585JJ+7ZVTmYbemcQapGqh1Zu3K66c82tHtT+vFNh9sBBdvCztA74UNwENDxkeQLVuO/+pEOLI9KC7yYXbKHN9sYWsC9XhmNAqt/Bjb9NE0UrL58miWHzu4HYFay3GX4cGHJuRPNx2U+79bluUrPDvhg4ptG1zZOkkzF0FY8AeK46UXf4m37v0DZT377A2mSwzAVOXKjXHi/VGpfPiJAj75hguTS4PoZu1ENkKPp0tTHhorHzfO1uEeZ/NZPrz4Wh3UJI9jj/W2oWG57v2HZRTp4+CjchFCL/SZ94m2j21x+0XbWo+WRF4hwIzWaAn+/NVbthz7IqcrdeIqBZgDshfzxB13HPcUJF9fjsaeKQT92LHhOSCrIN0XcyrVXH0tQNk1yXv2hnLzXx2UW24dkzOW4bNZWEIs8QWL0OpaYGflOBLPfOcJ++Liy4a2HvdDrgS6n8qtAMx+4YnzNyfBnXce/4gXhmvw0cZnCj5ATjW5aqJpgtQMubGbzppX95yb1nyT0Uhn52k+jW1+28n2CmcbZhpck/zDB8bkvR84KP/5UCgrlmM1CcBGnIg30mTlVbmycTafbY8OTdW4mq/a1irNzZdeWAA38LGFCi5ffOnQ1iXbdQ3f7YMagHliJ9YWmRGe2M/j2LswIsjUZNdcowYKkVZkY+NoZGk5V3VNWTe/m1b+pNl/FmTlp1TbAZSD52caqLl0pEZHY7n9S0fkuj87Ar8zkZcd68m4Mcm2fl1sqW2/yqwyIs7tk6rslfKZfKatGZrJm9Jw3oCLT+aWoxpwa5cK2R9HAUwil534nsWvQZMJMqbADMjgb801nwRAjdVKkabJOoqWl8+lpTwIYrYs5KjS8vIpDeCmZSn7dALrYaAztfvxstx400H5/O1jcuYZMMlYaCih1dYkp3K6bVXZO0fjmIsPaYY0y5d+jZoLq0vMbCtq/0KsyYMpCI1+4+VPnxV7/vYgGDg1CsfJKEhvvWoLs4e0t8wZHLOGqWjqprr5pqQZxlijZSz40LPIP96yWE5bGpjqtLg5WeePOlLMct/9o3LzLSNmRoBaWzIL/EBfmRn5bL1T09JKa8pOg2YuvlQGbOMu+DDLUTjhF5LLvrJlyY68Rf60FhPlarBmMOYaV8fX7jzlkSQoXFgOx/Z6wTxulcU6MTQHbTXmJI3NOFFDwzWGTqnNxzGKv7QsY+ZxaeQxJc1qFcvZ+VuVurGYWPFHk3zocCx/98VD8q6PHJEF8xNZtIgXDOXmLytLKnuNfHk0275sO0y7nbK0DHVpqQwoEsHDw4JCGft14ksaAZc9URdgZiDI58Jc3/WvJzwqADkEyByT0akhO8gIyBh5zTETplNSWkq3tNTUpflxygDrmndDA6NGacxv6maiwUA5qVj8Pfp/Jdn0sRfli3eMyyvxSAvlpDPF+slY22jilL+pD+f1HMkqQz1aJQ/zk7fy0PKT0MAc4Pr8KuoEHp675OtbT/o2MZnMLFMeDWxGQ0FNwRuu2r8aO/ru9f15p8IBs59ypeSmiVl2PDEVzRRuIB/ryAZuo7G9NIY9WbcbE43HksFSLWO2hJpkjtv//q1hufnzIzIfTzUsXgRHClrLl6TUhkbawBJT5CNbZpkqH7OYUOGHHRswy3EIzU0u+SbAVSw0Z714Sg3WwrxaVJPxTXQ6Xns9fx4fFaULYsS2sfuXzcn+y9Jsk7O52LyjaVkK8hBNBJrCeoGn+aNJfv5AJH/zhRflHR8flhMXiywYFBlLHw7P1kCuLaGhcvuvGX7WLFNzpwMu+6NhgJn5IbzgmiD/B8w13h6CWyiMybxPFjsZUjOuIj87p5M0ypgXqK1qkn/68Li854YD8qW7JuS1q7BQAAFxr2ECZXVlzsqux24+N7+mNZ5JPvAwYy7BhR/QtOZqPzQFMAsRZJoIghwHvtFkMxkCx4sN41VqHB8ntg22169tNNPp+Jubr3pu6ny2TlpW5s0GY5JxjtMB/3bXEbny/Qdl3wuRnHGSJ6N0pIxmaX0aW1nt3/o0bWtVTje/pjWeqt3WWQOvCrho17TBZV80DTALqbkmyAKQMeO1F3PXeAiTILtbcGyna0exE6pp21hLy+Zzz7npvHzgAABL0EIdd9Ucq0l+dl+IDXMH5E8+NSxnnCAyfwDjLe4iq3VrWmOtx5W3UZrLQ9MaT8XP9J29z4W3XNHcOve5xKNe4NA/7aD3yRfA8SqG4Q6AvBRviqEPyoc+Ohb64SR9He/g+OntL5Nfe8U8bHfFYyfp/fGPfjwun/zbQ/L4M5Esx45I3i93cTDgJgBXCvEl92xd2pRDldeuGQFMhurRrd247+USRTuwK/P0OBqzkyF5NbaBRsfp8Ggirzm7KB9857Fy2qmB7IcZvue+YXn/raPyCmjtILR2AuCqlrdBjJmyBLhFeMvlMTC6ZMcdJ+/Uvp0J4xkDzMrpeHFsXvvmfS+Pi+EOLDyfbma8zJvcaQjbHFAF9y4/fySRkxYX5NyzAnlkdyQ7H43k1Uvtum1ER6olrW1LW3ArZMGNo2j9fUOn3a/Wcaa1tazJerVdtGHfynIhvNeHJluQO2SuU5A5SbEHT+yfhDfdLcQGBw4YXR4q4MI7vfjb2075jvZlK+SelpOVV7E6Xt8aOvGx0I/WYMbrSU5rwtFJvWv1JFNHI+O90g2xqy95+dQzzy9rPFlM6eFdFtDkRFac4El/fyLj6R264Q2hdVrTHvNvpi7jAjZAy8he5VstW59m60b98JaLfCR0LIHmGnBn4FDl4dIyDVbmalpe9+anXo7lSjzANu/0mAsUqbmmZ2tMZRpTgIZoyM8iNWUno2mr0jpMQdDy6iJLPV+Jc2h5ZZXGcV3boLQaOVlFjSxm47kdc5PyWCGKW2qWKb4GytPyoCbmfJjruFC+1zheBmSYa4NSy6vsHYbmChADbgJwg9hruVl2O6NlJtplquZ6J8y1+PGayDXXvNqR2ZhJTWtMqqY1bpgGnqaMw4P1HEXT85RAZXHyTUVT2TWfK+dUNOY1Cwdmm80YXpZuzHKjCwdg33RAle0Lqsk013Hg2VuorCZTAtd8UZy5S6uY5ThK1v+Q3jJmBakQ7UKhrQBTaB2Taa5LhVLVXLuTIQqo28q5Qqu2ic/xYg9VaUziwsU/oLdMhwrLsdUsrU+1HWCKrPfJv7nhqZWYYroH68nLE2gyFLcFM16q/tPpnJmUbbw+dLLxlpO4NIrnR9b/YNvpHQGXEnYEYFakpui8jU+sCKMCpjUHlsdcTwbIHA3tOqym7PhYj6Z23EKk6m7jWthcWqP5dNRwy06PBjl1hmoELxa96IFtp35f+4L90u7QFicrT2h1vL63ZdmuyO9bE0Zju819Mt6LyPyElMDYlEnUpVXzV8vW0iwgtTRbRy0tL1+2fptHpbNyNkSzq0IRNdeC206Hykpd+5eXaEeDXr2v2fjcCokm4HjNXx6H7ty1q3+a1piialrjZmnaXG268tF4Mn5azs2XR6uct7dCABeP1K97YNuyjmquSqat1OOOxC7IyVEgs4N6OZiBxY65ABcX5LoHZwlc9mLHTLQLmZrrH21Zsgs7QnCfPLrbbP+pbBqwekqoe++XRAn3UAFcTL1eRHA7bZbdvp4VDVYBqppMxwv3yXC8ksxSoxo8jVlW0xrPJk3bksYVs4ydK+v+exY1V+WaFQ3WyquavGxX4Cec8dot/oBZoODWHjNhDzircfM061DZrTDK52gaLxr7r1pvHk1zVfk5W5CMWcYeqhEFdzY1V/t4VjVYhaho8pufW1HyxznjBceLCxQdWmpUQaYfW82NwxFs8rr4J0PLvteJSYxGxO0KgCmogvyqjU8vC0O+dHxgpdkZgneB1t6twzAb26yip4aayzXZ7RpKS7OYDqnQmD/tInMeB3qOFTREQ3nMLePFoD6cxSMoftH/DJ2BRzjbO/2YSt1QNKsm2pVQzfWPt5zyRBCY9WQsVMBc62My6En7GAjNtDXVNLncEmtipaGX7bFrRrM05ZEXa7kMX8O/Nj+cqCjxsXAAcPEo5zqC2w1m2e1XvYZd2qym9eo/6027lhUCzHhBk+20Zq25puBUMjd0gmbqQ0XYXxDhFTvQ3NKR2Cuue+TOpQ+o7K5Ms53uGg3WjqAms6Me+eqKJ/CIDB2vxySwmlxZSqTmogABrk+zGje9fPllyQtWA5prvlAGcMWCy4WDNq4Kaf80G3cdwGyAARkdRpCTgCCPAmTd/kNPluDiH9TIbvOZjGZyTTNfWpb1wOzbfwQd78SA5mJ78JHEaO7yB4xZbvOqULPAav6uM9EqGGM1eTTXeHx1h2fM9Rh3WtV8spZ5CbqaaI1J17TGeTSeY8jyyNJwbJf84tIRbLuG5i7vSrNMuTV0pQarcOp4UZM9o8kjRpMBhXk+2ZhLwKLmms6VpVmw3LTmqaVZvbROmy2j+XJo6X3uxBF8qdaA220OlfabG+vF69K6Lu1qchjIDs+fv1KiUWgyX8VIyLKhnr4yr3s+e6zn3DjdQwXNTTxv3WM9oLnaI2xFTwQFeTnMNb5rBHM9H971qFlPbmcDcPkYs4zFetwK9Ra47JeuNtEucOp47aZ3nSQXRuHILySYz80C3BmSmmZrovWYsZrtqWlVs655YaYxQwVvOS4dwoPma6m5vWCW3X7rGQ1WofVjXWf+4WOnxXFhO+6TVydlmGuz71pztSQ24OI+F+DK2l13nvkjtSIt4d4hJj0HMPtFO5ogRwAZ3vVqgbmG5rVgj5fpeQsuNBfesgGXmsvnrzqES8uq6UmA2foqyHtPC+Px7Z4/gHeHjIZ4e31TINOo271ftk9xkZiFA3yI6RDeRbVuz9Dq/+pVcNmingXYwIH3Mgq+rXgKNDmIvO1eESDDXFuQARUH00oLmahH48PXCRyqfj+JJw7BW177VI+aZdM36Z+ecbJcoStpgEtNfvqOlU+FfrI2Ko8axwtOWPU9XsDU3tOmiwjA2S5QWAfMnDM0fPDAOFRVcHvNoar0i5OoXN8OrfeSjiZ7kWBMnr86CUdwCwVzbRQXKOtSomp1ZWkQza0s+WHMhbdMzRVcONKFc8vNgjM3AGarU0BorqGimAwZXGVAVu+6Aizyuq3GU6dYzw0SjLn4ENjaZ+cQuOyW3jbRbIEGaltqrqXgrcHmiv+V4gK+dhFvrvf4sh2znl+JMeDyXIJFjAi3QnESrTPgwlueC5qr3TJ3AGaLDMj32TFZggvi8pHvesVjingdXgEKHAFQ3kphfMZme8xceMVFRWwN2oUTFzwLb1lo6nvwVkjBzItdY5V3vjdp6ZgsGx7uWyJ9H4eyvgPj8nF4mh7tAcT8Xz48jGF5CG8E2PT01tXPG3DhtPVmgyeXem4CzPby44zpBzdP+v1Hzkj6+lbGXnQa1nYDL/b34BM0u54fWvGo6Rp8ykDwtvvJu+lXZ7q0BzCBSfAmC+YLndwTMnfDnG5cBTYC+bDjO+/f6WEqLFYNr+T7VeJXPdBrPfD/VHWYLGZOSIcAAAAASUVORK5CYII=";

// Use embedded data URI directly so image loading never fails under any CSP or origin policy
const STREMIO_IMG = STREMIO_DATA_URI;

/* Function to get imdb code from DOM */
const getImdbCodeFromDom = (root = document) => {
  if (!root || !root.querySelectorAll) return null;
  const imdbLinks = root.querySelectorAll("a[href*='imdb.com/title/']");
  for (const a of imdbLinks) {
    const match = a.href?.match(/title\/(tt\d+)/);
    if (match?.[1]) {
      return match[1];
    }
  }
  return null;
};

/* Function to add a long press event-listener to remove stremio icon */
const addLongPressListener = (fabStremio) => {
  let pressTimer = null;
  let isLongPress = false;

  const handleLongPress = () => {
    isLongPress = true;
    fabStremio.style.display = "none";
  };

  const start = (e) => {
    if (e.type === "mousedown" && e.button !== 0) return;
    isLongPress = false;

    pressTimer = setTimeout(() => {
      handleLongPress();
    }, 1000);
  };

  const cancel = () => {
    if (pressTimer !== null) {
      clearTimeout(pressTimer);
      pressTimer = null;
    }
  };

  fabStremio.addEventListener("click", (e) => {
    if (isLongPress) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  });

  fabStremio.addEventListener("mousedown", start);
  fabStremio.addEventListener("mouseup", cancel);
  fabStremio.addEventListener("mouseleave", cancel);
  fabStremio.addEventListener("touchstart", start, { passive: true });
  fabStremio.addEventListener("touchend", cancel);
  fabStremio.addEventListener("touchcancel", cancel);

  if (typeof window !== "undefined") {
    let lastScrollY = window.scrollY;
    let ticking = false;

    window.addEventListener(
      "scroll",
      () => {
        if (!ticking) {
          window.requestAnimationFrame(() => {
            const currentScrollY = window.scrollY;
            if (currentScrollY > lastScrollY && currentScrollY > 100) {
              fabStremio.classList.add("fab-hidden");
            } else {
              fabStremio.classList.remove("fab-hidden");
            }
            lastScrollY = currentScrollY;
            ticking = false;
          });
          ticking = true;
        }
      },
      { passive: true },
    );
  }
};

/* Function to add Common Floating action button to search */
const addFabStremio = (contentType, imdbCode) => {
  if (typeof document === "undefined") return;
  if (document.getElementById("floating-btn")) {
    return;
  }

  const fabStremio = document.createElement("a");
  fabStremio.id = "floating-btn";
  fabStremio.href = `stremio:///detail/${encodeURIComponent(contentType)}/${encodeURIComponent(imdbCode)}`;
  fabStremio.title = "Watch on Stremio";
  fabStremio.setAttribute("aria-label", "Watch on Stremio");

  const img = document.createElement("img");
  img.style.width = "30px";
  img.style.height = "30px";
  img.src = STREMIO_IMG;
  img.alt = "Stremio";

  fabStremio.appendChild(img);
  document.body.appendChild(fabStremio);
  addLongPressListener(fabStremio);
};

/*****************************************************************/
/*    Search Engine: Google Specific Functions
/*****************************************************************/

// Function to work with mobile view
const addMobileStremioGoogle = (imdbCode, contentType) => {
  const stremioHref = `stremio:///detail/${encodeURIComponent(contentType)}/${encodeURIComponent(imdbCode)}`;
  try {
    const watchNowMain = document.querySelector(
      "div[role='list'][data-ved][lang]",
    );
    if (watchNowMain) {
      const mainTag = watchNowMain.querySelector("a[ping]");
      if (mainTag) {
        const img = mainTag.querySelector("img");
        if (img) img.src = STREMIO_IMG;
        mainTag.href = stremioHref;
      }
      const secTagContainer = watchNowMain.lastChild;
      const firstTag = secTagContainer?.querySelector?.("a[ping]");
      const firstTagDiv = firstTag?.parentElement;
      if (firstTagDiv) {
        const divImg = firstTagDiv.querySelector("img");
        if (divImg) divImg.src = STREMIO_IMG;

        const divAnchor = firstTagDiv.querySelector("a");
        if (divAnchor) divAnchor.href = stremioHref;

        const textSection = firstTagDiv.firstChild?.querySelector?.("div:nth-child(2)");
        if (textSection?.firstChild) {
          textSection.firstChild.textContent = "Stremio";
        }
        if (textSection?.lastChild) {
          textSection.lastChild.textContent = "Freedom to stream";
        }
        return;
      }
    }
    // Fallback to FAB if specific mobile watch-now container is not matched
    addFabStremio(contentType, imdbCode);
  } catch (error) {
    addFabStremio(contentType, imdbCode);
  }
};

// Main function for Google implementation
const addStremioButtonToGoogle = () => {
  if (typeof document === "undefined") return;

  const imdbCode = getImdbCodeFromDom();
  if (imdbCode === null) {
    return;
  }

  const seriesReviewContainer = document.querySelector(
    "div[data-attrid^='kc:/tv/tv_program:']",
  );
  const filmReviewContainer = document.querySelector(
    "div[data-attrid^='kc:/film/film:']",
  );

  let contentType = "movie";
  if (seriesReviewContainer !== null) {
    contentType = "series";
  }

  if (isMobile) {
    addMobileStremioGoogle(imdbCode, contentType);
    return;
  }

  const seriesOptions = document.querySelectorAll(
    "div[data-attrid='kc:/tv/tv_program:media_actions_wholepage']",
  );
  const movieOptions = document.querySelectorAll(
    "div[data-attrid='kc:/film/film:media_actions_wholepage']",
  );

  let watchOptions = [];
  if (seriesOptions.length !== 0) {
    watchOptions = [...seriesOptions];
  } else if (movieOptions.length !== 0) {
    watchOptions = [...movieOptions];
  }

  // Fallback to FAB if review container or search result has IMDb but no direct watchOptions row
  if (watchOptions.length === 0) {
    addFabStremio(contentType, imdbCode);
    return;
  }

  const stremioHref = `stremio:///detail/${encodeURIComponent(contentType)}/${encodeURIComponent(imdbCode)}`;

  watchOptions.forEach((watchOption) => {
    const container = watchOption.firstElementChild?.firstElementChild;
    if (!container) {
      return;
    }

    const stremioHref = `stremio:///detail/${encodeURIComponent(contentType)}/${encodeURIComponent(imdbCode)}`;
    const existingStremio = watchOption.querySelector(".stremio-cta__href");

    const isWatchlistButton = (el) => {
      const text = (el?.textContent || "").toLowerCase();
      return text.includes("already watched") || text.includes("want to watch") || text.includes("watchlist");
    };

    if (existingStremio) {
      existingStremio.href = stremioHref;
      // Remove any default watch provider that might still be present alongside Stremio
      const children = [...container.children];
      for (const child of children) {
        if (!child.querySelector(".stremio-cta__href") && !isWatchlistButton(child)) {
          child.remove();
        }
      }
      return;
    }

    const divEle = document.createElement("div");

    const anchor = document.createElement("a");
    anchor.className = "stremio-cta__href";
    anchor.href = stremioHref;

    const ctaContainer = document.createElement("div");
    ctaContainer.className = "streamio-cta__container";

    const img = document.createElement("img");
    img.style.width = "40px";
    img.style.height = "40px";
    img.src = STREMIO_IMG;
    img.alt = "Stremio";

    const titleDiv = document.createElement("div");
    titleDiv.textContent = "Stremio";

    const subTitleDiv = document.createElement("div");
    subTitleDiv.textContent = "Freedom to stream";

    ctaContainer.appendChild(img);
    ctaContainer.appendChild(titleDiv);
    ctaContainer.appendChild(subTitleDiv);
    anchor.appendChild(ctaContainer);
    divEle.appendChild(anchor);

    const firstAction = container.firstElementChild;
    if (firstAction) {
      if (!isWatchlistButton(firstAction)) {
        // Replace the default provider button (e.g. Netflix "Watch now") with Stremio
        if (typeof firstAction.replaceWith === "function") {
          firstAction.replaceWith(divEle);
        } else if (container.replaceChild) {
          container.replaceChild(divEle, firstAction);
        } else {
          container.insertBefore(divEle, firstAction);
          firstAction.remove();
        }
      } else {
        // Only watchlist buttons exist (e.g. "Already watched" & "Want to watch")
        container.insertBefore(divEle, firstAction);
      }
    } else {
      container.appendChild(divEle);
    }

    // Clean up any remaining non-watchlist default provider buttons
    const remainingChildren = [...container.children];
    for (const child of remainingChildren) {
      if (!child.querySelector(".stremio-cta__href") && !isWatchlistButton(child)) {
        child.remove();
      }
    }
  });
};

/*******************************************************/
/* Search Engine: DuckDuckGo Specific Functions
/*******************************************************/
const addStremioButtonToDuckDuckGo = () => {
  if (typeof document === "undefined") return;

  const titleSection = document.querySelector(
    'div[data-react-module-id="titles"]',
  );
  if (!titleSection) return;

  const imdbCode = getImdbCodeFromDom(titleSection) || getImdbCodeFromDom();
  if (imdbCode === null) {
    return;
  }

  const sectionText = (titleSection.innerText || titleSection.textContent || "").toLowerCase();
  const contentType =
    sectionText.includes("tv series") || sectionText.includes("television series")
      ? "series"
      : "movie";

  const stremioHref = `stremio:///detail/${encodeURIComponent(contentType)}/${encodeURIComponent(imdbCode)}`;

  try {
    const xpath = ".//span[text()='Quick links']";
    const quickLinksSpan = document.evaluate(
      xpath,
      titleSection,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null,
    ).singleNodeValue;

    // Add stremio to that imdb card if available
    if (quickLinksSpan) {
      const quickLinksDiv = quickLinksSpan.parentElement?.parentElement?.lastChild;
      if (quickLinksDiv) {
        if (quickLinksDiv.querySelector("a[href^='stremio:///detail/']")) {
          return;
        }
        const linksText = (quickLinksDiv.textContent || "").toLowerCase();
        if (linksText.includes("imdb") && quickLinksDiv.childElementCount <= 7) {
          const firstChild = quickLinksDiv.firstElementChild;
          if (firstChild) {
            const stremioLinkCopy = firstChild.cloneNode(true);
            stremioLinkCopy.href = stremioHref;
            const img = stremioLinkCopy.querySelector("img");
            if (img) img.src = STREMIO_IMG;
            const span = stremioLinkCopy.querySelector("span");
            if (span) span.textContent = "Stremio";
            quickLinksDiv.insertBefore(stremioLinkCopy, firstChild);
            return;
          }
        }
      }
    }
    // Fallback to add floating action button if imdb card quick links is not available
    addFabStremio(contentType, imdbCode);
  } catch (error) {
    addFabStremio(contentType, imdbCode);
  }
};

/*******************************************************/
/* Execution & Dynamic Mutation Observer
/*******************************************************/
let debounceTimer = null;
const debounced = (fn, delay = 250) => {
  return (...args) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => fn(...args), delay);
  };
};

const init = () => {
  if (typeof window === "undefined" || !window.location) return;
  const searchEngine = window.location.hostname;

  if (searchEngine.includes("google.")) {
    addStremioButtonToGoogle();
    if (typeof MutationObserver !== "undefined" && document.body) {
      const observer = new MutationObserver(debounced(addStremioButtonToGoogle, 250));
      observer.observe(document.body, { childList: true, subtree: true });
    }
  } else if (searchEngine.includes("duckduckgo.")) {
    addStremioButtonToDuckDuckGo();
    if (typeof MutationObserver !== "undefined" && document.body) {
      const observer = new MutationObserver(debounced(addStremioButtonToDuckDuckGo, 250));
      observer.observe(document.body, { childList: true, subtree: true });
    }
    document.addEventListener(
      "animationstart",
      function (event) {
        if (event.animationName === "quickLinkAppeared") {
          addStremioButtonToDuckDuckGo();
        }
      },
      true,
    );
  }
};

if (typeof document !== "undefined") {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = {
    getImdbCodeFromDom,
    addLongPressListener,
    addFabStremio,
    addMobileStremioGoogle,
    addStremioButtonToGoogle,
    addStremioButtonToDuckDuckGo,
    init,
  };
}
